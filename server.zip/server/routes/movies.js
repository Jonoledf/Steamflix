const express = require('express');
const Movie = require('../models/Movie');
const { auth, adminAuth } = require('../middleware/auth');

const router = express.Router();

// Get all movies (public)
router.get('/', async (req, res) => {
  try {
    const { genre, search, page = 1, limit = 10 } = req.query;
    const query = {};

    // Filter by genre
    if (genre && genre !== 'all') {
      query.genre = new RegExp(genre, 'i');
    }

    // Search by title
    if (search) {
      query.title = new RegExp(search, 'i');
    }

    const movies = await Movie.find(query)
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Movie.countDocuments(query);

    res.json({
      movies,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get featured movies (public)
router.get('/featured', async (req, res) => {
  try {
    const movies = await Movie.find()
      .sort({ views: -1, rating: -1 })
      .limit(6);

    res.json(movies);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get single movie (public)
router.get('/:id', async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id);
    
    if (!movie) {
      return res.status(404).json({ message: 'Movie not found' });
    }

    // Increment views
    movie.views += 1;
    await movie.save();

    res.json(movie);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Create movie (admin only)
router.post('/', adminAuth, async (req, res) => {
  try {
    const { title, description, genre, year, poster, videoUrl, rating } = req.body;

    const movie = new Movie({
      title,
      description,
      genre,
      year,
      poster,
      videoUrl,
      rating
    });

    await movie.save();

    res.status(201).json({
      message: 'Movie created successfully',
      movie
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Update movie (admin only)
router.put('/:id', adminAuth, async (req, res) => {
  try {
    const { title, description, genre, year, poster, videoUrl, rating } = req.body;

    const movie = await Movie.findByIdAndUpdate(
      req.params.id,
      {
        title,
        description,
        genre,
        year,
        poster,
        videoUrl,
        rating,
        updatedAt: Date.now()
      },
      { new: true }
    );

    if (!movie) {
      return res.status(404).json({ message: 'Movie not found' });
    }

    res.json({
      message: 'Movie updated successfully',
      movie
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Delete movie (admin only)
router.delete('/:id', adminAuth, async (req, res) => {
  try {
    const movie = await Movie.findByIdAndDelete(req.params.id);

    if (!movie) {
      return res.status(404).json({ message: 'Movie not found' });
    }

    res.json({ message: 'Movie deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;
