require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Movie = require('../models/Movie');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/steamflix';

const seedData = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(MONGODB_URI);
    console.log('Connected to MongoDB');

    // Clear existing data
    await User.deleteMany({});
    await Movie.deleteMany({});
    console.log('Cleared existing data');

    // Create admin user
    const adminUser = new User({
      email: 'admin@steamflix.com',
      password: 'admin123',
      role: 'admin'
    });
    await adminUser.save();
    console.log('Admin user created');

    // Create sample movies
    const movies = [
      {
        title: "Avatar: The Way of Water",
        description: "Jake Sully vit avec sa nouvelle famille formée sur la planète Pandora. Lorsqu'une menace familière revient pour finir ce qui avait été commencé auparavant, Jake doit travailler avec Neytiri et l'armée de la race Na'vi pour protéger leur planète.",
        genre: "Action",
        year: 2022,
        poster: "https://image.tmdb.org/t/p/w500/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg",
        videoUrl: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
        rating: 4.5,
        views: 1250
      },
      {
        title: "Top Gun: Maverick",
        description: "Après plus de trente ans de service en tant que l'un des meilleurs aviateurs de la Navy, Pete 'Maverick' Mitchell est à sa place, repoussant les limites en tant que pilote d'essai courageux et esquivant l'avancement de grade qui le mettrait à la terre.",
        genre: "Action",
        year: 2022,
        poster: "https://image.tmdb.org/t/p/w500/62HCnUTziyWcpDaBO2i1DX17ljH.jpg",
        videoUrl: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_2mb.mp4",
        rating: 4.8,
        views: 2100
      },
      {
        title: "The Batman",
        description: "Lorsque le Riddler, un tueur sadique, commence à assassiner des personnalités politiques clés de Gotham, Batman est contraint d'enquêter sur la corruption cachée de la ville et de remettre en question l'implication de sa propre famille.",
        genre: "Action",
        year: 2022,
        poster: "https://image.tmdb.org/t/p/w500/b0PlSFdDwbyK0cf5RxwDpaOJQvQ.jpg",
        videoUrl: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_5mb.mp4",
        rating: 4.3,
        views: 1800
      },
      {
        title: "Spider-Man: No Way Home",
        description: "Pour la première fois dans l'histoire cinématographique de Spider-Man, notre héros sympathique du quartier est démasqué et ne peut plus séparer sa vie normale des enjeux élevés d'être un super-héros.",
        genre: "Action",
        year: 2021,
        poster: "https://image.tmdb.org/t/p/w500/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg",
        videoUrl: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
        rating: 4.7,
        views: 3200
      },
      {
        title: "Dune",
        description: "Paul Atreides, un jeune homme brillant et doué, né avec un grand destin qui le dépasse, doit se rendre sur la planète la plus dangereuse de l'univers pour assurer l'avenir de sa famille et de son peuple.",
        genre: "Science-Fiction",
        year: 2021,
        poster: "https://image.tmdb.org/t/p/w500/d5NXSklXo0qyIYkgV94XAgMIckC.jpg",
        videoUrl: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_2mb.mp4",
        rating: 4.4,
        views: 1600
      },
      {
        title: "Encanto",
        description: "L'histoire d'une famille extraordinaire, les Madrigal, qui vivent cachés dans les montagnes de Colombie, dans une maison magique, dans une ville dynamique, dans un endroit merveilleux connu sous le nom d'Encanto.",
        genre: "Animation",
        year: 2021,
        poster: "https://image.tmdb.org/t/p/w500/4j0PNHkMr5ax3IA8tjtxcmPU3QT.jpg",
        videoUrl: "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
        rating: 4.6,
        views: 2800
      }
    ];

    await Movie.insertMany(movies);
    console.log('Sample movies created');

    console.log('Seed data completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error seeding data:', error);
    process.exit(1);
  }
};

seedData();
