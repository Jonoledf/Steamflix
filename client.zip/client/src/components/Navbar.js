import { Link } from 'react-router-dom';
import { FilmIcon, HomeIcon, CogIcon } from '@heroicons/react/24/outline';

const Navbar = () => {
  return (
    <nav className="bg-gray-800 shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <FilmIcon className="h-8 w-8 text-red-500" />
              <span className="text-xl font-bold text-white">SteamFlix</span>
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            <Link
              to="/"
              className="flex items-center space-x-1 text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium"
            >
              <HomeIcon className="h-5 w-5" />
              <span>Accueil</span>
            </Link>
            
            <Link
              to="/movies"
              className="flex items-center space-x-1 text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium"
            >
              <FilmIcon className="h-5 w-5" />
              <span>Films</span>
            </Link>
            
            <Link
              to="/admin"
              className="flex items-center space-x-1 text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium"
            >
              <CogIcon className="h-5 w-5" />
              <span>Admin</span>
            </Link>
            
            <Link
              to="/login"
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium"
            >
              Connexion
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
