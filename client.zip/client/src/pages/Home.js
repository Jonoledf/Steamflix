import { useState, useEffect } from 'react';
import { PlayIcon } from '@heroicons/react/24/solid';

const Home = () => {
  const [featuredMovies, setFeaturedMovies] = useState([]);

  useEffect(() => {
    // Simulation de données pour les films en vedette
    setFeaturedMovies([
      {
        id: 1,
        title: "Avatar: The Way of Water",
        description: "Jake Sully vit avec sa nouvelle famille formée sur la planète Pandora.",
        poster: "https://via.placeholder.com/300x450/1f2937/ffffff?text=Avatar+2",
        backdrop: "https://via.placeholder.com/1920x1080/1f2937/ffffff?text=Avatar+2+Backdrop"
      },
      {
        id: 2,
        title: "Top Gun: Maverick",
        description: "Après plus de trente ans de service, Pete 'Maverick' Mitchell continue à repousser ses limites.",
        poster: "https://via.placeholder.com/300x450/1f2937/ffffff?text=Top+Gun",
        backdrop: "https://via.placeholder.com/1920x1080/1f2937/ffffff?text=Top+Gun+Backdrop"
      }
    ]);
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative h-96 bg-gradient-to-r from-gray-900 to-gray-700">
        <div className="absolute inset-0 bg-black opacity-50"></div>
        <div className="relative z-10 flex items-center justify-center h-full">
          <div className="text-center">
            <h1 className="text-5xl font-bold text-white mb-4">
              Bienvenue sur SteamFlix
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Découvrez des milliers de films en streaming
            </p>
            <button className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-8 rounded-lg flex items-center mx-auto">
              <PlayIcon className="h-6 w-6 mr-2" />
              Commencer à regarder
            </button>
          </div>
        </div>
      </div>

      {/* Featured Movies */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-white mb-8">Films en vedette</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredMovies.map((movie) => (
            <div key={movie.id} className="bg-gray-800 rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
              <img
                src={movie.poster}
                alt={movie.title}
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-2">{movie.title}</h3>
                <p className="text-gray-400 mb-4">{movie.description}</p>
                <button className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded flex items-center">
                  <PlayIcon className="h-5 w-5 mr-2" />
                  Regarder
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;
