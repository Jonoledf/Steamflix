import { useState, useEffect } from 'react';
import { PlayIcon, MagnifyingGlassIcon } from '@heroicons/react/24/solid';

const Movies = () => {
  const [movies, setMovies] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');

  const genres = [
    { id: 'all', name: 'Tous les genres' },
    { id: 'action', name: 'Action' },
    { id: 'comedy', name: 'Comédie' },
    { id: 'drama', name: 'Drame' },
    { id: 'horror', name: 'Horreur' },
  ];

  useEffect(() => {
    // Simulation de données pour la liste des films
    setMovies([
      {
        id: 1,
        title: "Avatar: The Way of Water",
        genre: "action",
        year: 2022,
        poster: "https://via.placeholder.com/300x450/1f2937/ffffff?text=Avatar+2",
        rating: 4.5
      },
      {
        id: 2,
        title: "Top Gun: Maverick",
        genre: "action",
        year: 2022,
        poster: "https://via.placeholder.com/300x450/1f2937/ffffff?text=Top+Gun",
        rating: 4.8
      },
      {
        id: 3,
        title: "The Batman",
        genre: "action",
        year: 2022,
        poster: "https://via.placeholder.com/300x450/1f2937/ffffff?text=Batman",
        rating: 4.3
      }
    ]);
  }, []);

  const filteredMovies = movies.filter(movie => {
    const matchesSearch = movie.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGenre = selectedGenre === 'all' || movie.genre === selectedGenre;
    return matchesSearch && matchesGenre;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Search and Filter Section */}
      <div className="mb-8 space-y-4">
        <div className="relative">
          <MagnifyingGlassIcon className="h-5 w-5 text-gray-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Rechercher un film..."
            className="w-full pl-10 pr-4 py-2 bg-gray-800 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex flex-wrap gap-2">
          {genres.map((genre) => (
            <button
              key={genre.id}
              className={`px-4 py-2 rounded-full ${
                selectedGenre === genre.id
                  ? 'bg-red-600 text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
              onClick={() => setSelectedGenre(genre.id)}
            >
              {genre.name}
            </button>
          ))}
        </div>
      </div>

      {/* Movies Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {filteredMovies.map((movie) => (
          <div key={movie.id} className="bg-gray-800 rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
            <div className="relative group">
              <img
                src={movie.poster}
                alt={movie.title}
                className="w-full h-96 object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-opacity flex items-center justify-center">
                <button className="opacity-0 group-hover:opacity-100 bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-full flex items-center transform transition-all scale-95 hover:scale-100">
                  <PlayIcon className="h-5 w-5 mr-2" />
                  Regarder
                </button>
              </div>
            </div>
            <div className="p-4">
              <h3 className="text-lg font-semibold text-white mb-1">{movie.title}</h3>
              <div className="flex justify-between text-sm text-gray-400">
                <span>{movie.year}</span>
                <span>★ {movie.rating}/5</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Movies;
